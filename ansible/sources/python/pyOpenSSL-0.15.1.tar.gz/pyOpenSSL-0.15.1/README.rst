
pyOpenSSL - A Python wrapper around the OpenSSL library
------------------------------------------------------------------------------

See the file INSTALL.rst for installation instructions.

See https://github.com/pyca/pyopenssl for development.

See https://pyopenssl.readthedocs.org for documentation.

See https://mail.python.org/mailman/listinfo/pyopenssl-users for the discussion mailing list.

.. image:: https://coveralls.io/repos/pyca/pyopenssl/badge.png
  :target: https://coveralls.io/r/pyca/pyopenssl
