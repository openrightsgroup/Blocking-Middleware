
ASN.1 modules for Python
------------------------

This is a small but growing collection of ASN.1 data structures
[1] expressed in Python terms using pyasn1 [2] data model.

It's thought to be useful to protocol developers and testers.

All modules are py2k/py3k-compliant.

If you happen to convert some ASN.1 module into pyasn1 that is not
yet present in this collection and wish to contribute - please send
it to me.

=-=-=
mailto: ilya@glas.net
