Launching Tor
=============

.. note::

  Please see :class:`txtorcon.TCPHiddenServiceEndpoint` In general, endpoints
  are an easier way to interact with launching Tor. However, if you do
  need configuration control, you can do that too and you're in the
  right spot.

get_global_tor
--------------

.. autofunction:: txtorcon.get_global_tor

TorProcessProtocol
------------------
.. autoclass:: txtorcon.TorProcessProtocol

launch_tor
----------
.. autofunction:: txtorcon.launch_tor
