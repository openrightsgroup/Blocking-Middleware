Configuration Classes
=====================

TorConfig
---------
.. autoclass:: txtorcon.TorConfig

HiddenService
-------------
.. autoclass:: txtorcon.HiddenService
