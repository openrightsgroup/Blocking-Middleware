License and Hall of Fame
========================

``service_identity`` is licensed under the permissive `MIT <http://choosealicense.com/licenses/mit/>`_ license.
The full license text can be also found in the `source code repository <https://github.com/pyca/service_identity/blob/master/LICENSE>`_.

.. _authors:

.. include:: ../AUTHORS.rst
